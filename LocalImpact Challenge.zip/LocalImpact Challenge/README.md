# 🎓 Student Survey Dashboard - User Input Module

An interactive, responsive end-to-end web application for collecting, storing, and visualizing student survey responses using **Python**, **Streamlit**, **Pandas**, and **CSV Storage**.

---

## 🌟 Overview

The **User Input Module** serves as the central data intake point for the Student Survey Dashboard. Students fill out their feedback through a streamlined form, their responses are validated and safely appended to a local CSV file, and the analytics dashboard immediately updates with real-time statistics and visualizations.

---

## 🏗️ Workflow & Architecture

```
┌────────────────────────┐
│  1. Student Enters     │ ➔ Student enters Name, Department, Year, Satisfaction & Feedback
│     Details            │
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│  2. Submit Survey      │ ➔ Atomic form submission & input validation
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│  3. Store Data in CSV  │ ➔ Append new row to `survey_responses.csv` with timestamp
└───────────┬────────────┘
            │
            ▼
┌────────────────────────┐
│  4. Analyse & Display  │ ➔ Real-time KPIs, interactive charts, and searchable data table
│     Dashboard          │
└────────────────────────┘
```

---

## 📋 Features

### 1. User Input Form (Frontend)
- **Student Name**: Text input (`Enter your name`)
- **Department**: Selectbox (`CSE`, `ECE`, `MECH`, `IT`, `CIVIL`, `EEE`, `AI & DS`)
- **Academic Year**: Radio selection (`1st Year`, `2nd Year`, `3rd Year`, `4th Year`)
- **Overall Satisfaction**: Visual radio choices (`Excellent`, `Good`, `Average`, `Poor`)
- **Additional Feedback**: Multiline text area (`Enter your feedback...`)
- **Demo Note**: *"Demo form only. Responses are stored in local CSV file storage."*
- **Submit Button**: Validates inputs, saves to CSV, triggers celebratory animations, and instantly reloads dashboard metrics.

### 2. Python Backend & Data Engine
- **Framework**: Streamlit for clean web UI and reactive execution.
- **Data Engine**: Pandas for reading, validating, filtering, and aggregating survey responses.
- **Data Storage**: CSV file (`survey_responses.csv`) ensuring zero database configuration overhead while remaining persistent, portable, and easily exportable.

### 3. Analytics Dashboard
- **Key Metrics (KPIs)**:
  - Total Submissions counter
  - Positive Sentiment percentage (% Excellent + Good)
  - Most Active Department
  - Top Participating Academic Year
- **Interactive Visualizations**:
  - Color-coded bar chart of satisfaction levels
  - Department-wise submission breakdown
  - Academic year distribution donut chart
  - Recent qualitative quotes highlighting student sentiment
- **Data Explorer & Export**:
  - Filter by Department or Satisfaction level
  - Live keyword search across student names and feedback
  - Direct 1-click CSV download of all or filtered responses

---

## 📁 Project Structure

```
LocalImpact Challenge/
├── app.py                  # Main Streamlit application
├── survey_responses.csv    # Local CSV database storing student responses
├── requirements.txt        # Python package dependencies
├── run.bat                 # 1-click Windows launcher
└── README.md               # Complete project documentation
```

---

## 🚀 Getting Started

### Prerequisites
Make sure Python 3.9+ is installed on your machine.

### Installation
1. Open your terminal or Command Prompt in this folder:
   ```bash
   pip install -r requirements.txt
   ```

2. Run the Streamlit application:
   ```bash
   python -m streamlit run app.py
   ```
   *(Or simply double-click `run.bat` on Windows)*

3. Open your browser at:
   ```
   http://localhost:8501
   ```

---

## 📊 CSV Storage Schema

| Field | Type | Description |
| :--- | :--- | :--- |
| `Timestamp` | DateTime (YYYY-MM-DD HH:MM:SS) | Generated upon submission |
| `Student Name` | String | Entered student name |
| `Department` | String | Department code (CSE, ECE, MECH, etc.) |
| `Academic Year` | String | Academic year (1st, 2nd, 3rd, 4th Year) |
| `Overall Satisfaction` | String | Excellent, Good, Average, Poor |
| `Additional Feedback` | Text | Qualitative student comments |
