import streamlit as st
import pandas as pd
import os
from datetime import datetime
import altair as alt

# ---------------------------------------------------------
# Page Configuration
# ---------------------------------------------------------
st.set_page_config(
    page_title="Student Survey Dashboard",
    page_icon="🎓",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ---------------------------------------------------------
# Custom Styling
# ---------------------------------------------------------
st.markdown("""
<style>
    /* Global font & background enhancements */
    .main-title {
        font-size: 2.2rem;
        font-weight: 700;
        color: #1E3A8A;
        margin-bottom: 0.2rem;
    }
    .sub-title {
        font-size: 1.05rem;
        color: #4B5563;
        margin-bottom: 1.5rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #F8FAFC 0%, #EFF6FF 100%);
        border-radius: 12px;
        padding: 1.2rem;
        border: 1px solid #DBEAFE;
        box-shadow: 0 2px 4px rgba(0,0,0,0.04);
        text-align: center;
    }
    .metric-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #1D4ED8;
    }
    .metric-label {
        font-size: 0.85rem;
        color: #64748B;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }
    .badge-demo {
        background-color: #FEF3C7;
        color: #92400E;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 0.85rem;
        display: inline-block;
        margin-top: 10px;
        border: 1px solid #FCD34D;
    }
    .feedback-quote {
        background-color: #F8FAFC;
        border-left: 4px solid #3B82F6;
        padding: 12px 16px;
        border-radius: 4px;
        margin-bottom: 10px;
    }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------
# CSV Storage Configuration & Helpers
# ---------------------------------------------------------
CSV_FILE = "survey_responses.csv"
CSV_COLUMNS = [
    "Timestamp",
    "Student Name",
    "Department",
    "Academic Year",
    "Overall Satisfaction",
    "Additional Feedback",
]

def initialize_csv():
    """Initializes the CSV storage file with headers if it does not exist."""
    if not os.path.exists(CSV_FILE):
        df = pd.DataFrame(columns=CSV_COLUMNS)
        df.to_csv(CSV_FILE, index=False)

def load_data():
    """Loads survey responses from CSV into a Pandas DataFrame."""
    initialize_csv()
    try:
        df = pd.read_csv(CSV_FILE)
        # Ensure all expected columns are present
        for col in CSV_COLUMNS:
            if col not in df.columns:
                df[col] = ""
        return df
    except Exception as e:
        st.error(f"Error loading CSV data: {e}")
        return pd.DataFrame(columns=CSV_COLUMNS)

def save_response(name, department, year, satisfaction, feedback):
    """Appends a new survey response to the CSV file."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    new_entry = {
        "Timestamp": timestamp,
        "Student Name": name.strip(),
        "Department": department,
        "Academic Year": year,
        "Overall Satisfaction": satisfaction,
        "Additional Feedback": feedback.strip() if feedback else "N/A",
    }
    new_df = pd.DataFrame([new_entry])
    
    # Check if file exists and has headers
    file_exists = os.path.exists(CSV_FILE) and os.path.getsize(CSV_FILE) > 0
    new_df.to_csv(CSV_FILE, mode="a", index=False, header=not file_exists)
    return timestamp

# Load data on each run
df_responses = load_data()

# ---------------------------------------------------------
# Sidebar
# ---------------------------------------------------------
with st.sidebar:
    st.image("https://cdn-icons-png.flaticon.com/512/3135/3135755.png", width=70)
    st.title("Student Survey Hub")
    st.caption("User Input & Analytics Engine")
    
    st.divider()
    
    # Real-time Quick Stats in Sidebar
    total_count = len(df_responses)
    st.markdown("### 📌 Quick Overview")
    st.metric("Total Submissions", f"{total_count} responses")
    
    if total_count > 0:
        excellent_count = (df_responses["Overall Satisfaction"] == "Excellent").sum()
        good_count = (df_responses["Overall Satisfaction"] == "Good").sum()
        positive_pct = round(((excellent_count + good_count) / total_count) * 100, 1)
        st.metric("Positive Sentiment", f"{positive_pct}%")
    
    st.divider()
    
    st.markdown("### ⚙️ Storage Backend")
    st.markdown(f"""
    - **Engine:** Python & Pandas
    - **Database:** Local CSV File
    - **Target File:** `{CSV_FILE}`
    - **Status:** {'🟢 Active & Connected' if os.path.exists(CSV_FILE) else '🟡 Creating on first write'}
    """)
    
    st.divider()
    
    # Download raw CSV data directly
    if total_count > 0:
        csv_data = df_responses.to_csv(index=False).encode("utf-8")
        st.download_button(
            label="📥 Download CSV Dataset",
            data=csv_data,
            file_name=f"survey_responses_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
            mime="text/csv",
            use_container_width=True,
        )

# ---------------------------------------------------------
# Main Page Header
# ---------------------------------------------------------
st.markdown('<div class="main-title">🎓 Student Survey Dashboard</div>', unsafe_allow_html=True)
st.markdown('<div class="sub-title">Collect student feedback, store responses in CSV, and analyse insights in real-time.</div>', unsafe_allow_html=True)

# Navigation Tabs
tab_form, tab_analytics, tab_records, tab_architecture = st.tabs([
    "📝 Survey Input Form",
    "📊 Analytics Dashboard",
    "📋 Survey Records",
    "🏗️ Workflow & Architecture",
])

# ---------------------------------------------------------
# TAB 1: User Input Form
# ---------------------------------------------------------
with tab_form:
    st.markdown("### Student Survey Form")
    st.write("Please fill in your details and share your feedback.")
    
    col_form, col_info = st.columns([2, 1], gap="large")
    
    with col_form:
        # Wrap inputs inside st.form for standard atomic submission
        with st.form("student_survey_form", clear_on_submit=True):
            # Student Name
            student_name = st.text_input(
                "Student Name",
                placeholder="Enter your name",
                help="Enter your full name or student ID",
            )
            
            # Department
            department_options = ["CSE", "ECE", "MECH", "IT", "CIVIL", "EEE", "AI & DS"]
            department = st.selectbox(
                "Department",
                options=department_options,
                index=0,
                help="Select your enrolled department",
            )
            
            # Academic Year
            academic_year_options = ["1st Year", "2nd Year", "3rd Year", "4th Year"]
            academic_year = st.radio(
                "Academic Year",
                options=academic_year_options,
                index=0,
                horizontal=True,
                help="Select your current year of study",
            )
            
            # Overall Satisfaction
            satisfaction_options = ["Excellent", "Good", "Average", "Poor"]
            satisfaction = st.radio(
                "Overall Satisfaction",
                options=satisfaction_options,
                index=0,
                horizontal=True,
                help="Rate your overall academic & campus experience",
            )
            
            # Additional Feedback
            additional_feedback = st.text_area(
                "Additional Feedback",
                placeholder="Enter your feedback...",
                height=120,
                help="Share any thoughts, suggestions, or issues",
            )
            
            # Demo note requirement
            st.markdown(
                '<div class="badge-demo">ℹ️ Demo form only. Responses are stored in local CSV file storage.</div>',
                unsafe_allow_html=True,
            )
            
            st.write("")
            submit_button = st.form_submit_button("Submit Survey", use_container_width=True, type="primary")
            
            if submit_button:
                if not student_name.strip():
                    st.error("⚠️ Please enter your name before submitting.")
                else:
                    saved_time = save_response(
                        name=student_name,
                        department=department,
                        year=academic_year,
                        satisfaction=satisfaction,
                        feedback=additional_feedback,
                    )
                    st.balloons()
                    st.success(f"🎉 Thank you, **{student_name.strip()}**! Your survey response was recorded successfully at {saved_time}.")
                    # Rerun to update counts and live dashboard immediately
                    st.rerun()
    
    with col_info:
        st.markdown("#### 💡 How User Input Works")
        st.info("""
        1. **Student fills form:** Name, Department, Year, Satisfaction rating, and feedback.
        2. **Client Validation:** Ensures required fields are provided before submission.
        3. **Python Execution:** Backend serializes the payload.
        4. **CSV Persistence:** Appends entry directly to `survey_responses.csv`.
        5. **Instant Analytics:** Dashboard auto-refreshes to reflect your newly submitted data.
        """)
        
        st.markdown("#### 🚀 Test Submission Checklist")
        st.write("Try submitting tests for various departments:")
        st.markdown("""
        - [x] **CSE** - Excellent (Hands-on labs)
        - [ ] **ECE** - Good (Workshops)
        - [ ] **MECH** - Average (Practical sessions)
        - [ ] **AI & DS** - Excellent (ML projects)
        """)

# ---------------------------------------------------------
# TAB 2: Analytics & Dashboard
# ---------------------------------------------------------
with tab_analytics:
    df_current = load_data()
    
    if df_current.empty or len(df_current) == 0:
        st.warning("⚠️ No survey records found in `survey_responses.csv`. Submit the form above to see live analytics!")
    else:
        total_sub = len(df_current)
        
        # Satisfaction breakdown counts
        sat_counts = df_current["Overall Satisfaction"].value_counts().to_dict()
        excellent_n = sat_counts.get("Excellent", 0)
        good_n = sat_counts.get("Good", 0)
        average_n = sat_counts.get("Average", 0)
        poor_n = sat_counts.get("Poor", 0)
        
        positive_rate = round(((excellent_n + good_n) / total_sub) * 100, 1) if total_sub > 0 else 0
        top_dept = df_current["Department"].mode()[0] if not df_current["Department"].empty else "N/A"
        top_year = df_current["Academic Year"].mode()[0] if not df_current["Academic Year"].empty else "N/A"
        
        # KPI Metric Row
        m_col1, m_col2, m_col3, m_col4 = st.columns(4)
        with m_col1:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Total Submissions</div>
                <div class="metric-value">{total_sub}</div>
            </div>
            """, unsafe_allow_html=True)
        with m_col2:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Positive Sentiment</div>
                <div class="metric-value">{positive_rate}%</div>
            </div>
            """, unsafe_allow_html=True)
        with m_col3:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Most Active Dept</div>
                <div class="metric-value">{top_dept}</div>
            </div>
            """, unsafe_allow_html=True)
        with m_col4:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-label">Top Academic Year</div>
                <div class="metric-value">{top_year}</div>
            </div>
            """, unsafe_allow_html=True)
            
        st.write("")
        st.divider()
        
        # Visualization Section
        c_col1, c_col2 = st.columns(2, gap="medium")
        
        with c_col1:
            st.subheader("📈 Satisfaction Level Breakdown")
            sat_df = pd.DataFrame({
                "Satisfaction": ["Excellent", "Good", "Average", "Poor"],
                "Count": [excellent_n, good_n, average_n, poor_n],
            })
            
            # Altair colored bar chart
            color_scale = alt.Scale(
                domain=["Excellent", "Good", "Average", "Poor"],
                range=["#10B981", "#3B82F6", "#F59E0B", "#EF4444"]
            )
            sat_chart = alt.Chart(sat_df).mark_bar(cornerRadiusTopLeft=8, cornerRadiusTopRight=8).encode(
                x=alt.X("Satisfaction:N", sort=["Excellent", "Good", "Average", "Poor"], title="Satisfaction Level"),
                y=alt.Y("Count:Q", title="Number of Responses"),
                color=alt.Color("Satisfaction:N", scale=color_scale, legend=None),
                tooltip=["Satisfaction", "Count"]
            ).properties(height=300)
            
            st.altair_chart(sat_chart, use_container_width=True)
            
        with c_col2:
            st.subheader("🏛️ Responses by Department")
            dept_df = df_current["Department"].value_counts().reset_index()
            dept_df.columns = ["Department", "Responses"]
            
            dept_chart = alt.Chart(dept_df).mark_bar(cornerRadiusTopLeft=8, cornerRadiusTopRight=8, color="#4F46E5").encode(
                x=alt.X("Department:N", sort="-y", title="Department"),
                y=alt.Y("Responses:Q", title="Responses Count"),
                tooltip=["Department", "Responses"]
            ).properties(height=300)
            
            st.altair_chart(dept_chart, use_container_width=True)
            
        c_col3, c_col4 = st.columns(2, gap="medium")
        
        with c_col3:
            st.subheader("📅 Academic Year Distribution")
            year_df = df_current["Academic Year"].value_counts().reset_index()
            year_df.columns = ["Academic Year", "Count"]
            
            year_chart = alt.Chart(year_df).mark_arc(innerRadius=50).encode(
                theta=alt.Theta(field="Count", type="quantitative"),
                color=alt.Color(field="Academic Year", type="nominal", title="Year"),
                tooltip=["Academic Year", "Count"]
            ).properties(height=300)
            
            st.altair_chart(year_chart, use_container_width=True)
            
        with c_col4:
            st.subheader("💬 Recent Student Quotes")
            # Show last 3 feedbacks that aren't empty
            valid_feedbacks = df_current[
                df_current["Additional Feedback"].str.strip().ne("") & 
                df_current["Additional Feedback"].ne("N/A")
            ].tail(3).iloc[::-1]
            
            if not valid_feedbacks.empty:
                for _, row in valid_feedbacks.iterrows():
                    sat_icon = "🟢" if row["Overall Satisfaction"] == "Excellent" else ("🔵" if row["Overall Satisfaction"] == "Good" else ("🟡" if row["Overall Satisfaction"] == "Average" else "🔴"))
                    st.markdown(f"""
                    <div class="feedback-quote">
                        <strong>{row['Student Name']}</strong> ({row['Department']} - {row['Academic Year']}) {sat_icon} <em>{row['Overall Satisfaction']}</em><br>
                        <span style="color: #374151;">"{row['Additional Feedback']}"</span>
                    </div>
                    """, unsafe_allow_html=True)
            else:
                st.caption("No written feedback submitted yet.")

# ---------------------------------------------------------
# TAB 3: Survey Records Table & Export
# ---------------------------------------------------------
with tab_records:
    st.subheader("📋 Submitted Survey Records")
    
    df_records = load_data()
    
    if df_records.empty or len(df_records) == 0:
        st.info("No records to display. Submit a survey to start collecting data.")
    else:
        # Filter controls
        f_col1, f_col2, f_col3 = st.columns([1, 1, 2])
        
        with f_col1:
            depts_available = ["All"] + sorted(list(df_records["Department"].dropna().unique()))
            selected_dept = st.selectbox("Filter by Department", depts_available)
            
        with f_col2:
            sat_available = ["All"] + ["Excellent", "Good", "Average", "Poor"]
            selected_sat = st.selectbox("Filter by Satisfaction", sat_available)
            
        with f_col3:
            search_query = st.text_input("Search Name or Feedback", placeholder="Type keywords...")
            
        # Apply filters
        filtered_df = df_records.copy()
        if selected_dept != "All":
            filtered_df = filtered_df[filtered_df["Department"] == selected_dept]
        if selected_sat != "All":
            filtered_df = filtered_df[filtered_df["Overall Satisfaction"] == selected_sat]
        if search_query.strip():
            q = search_query.strip().lower()
            filtered_df = filtered_df[
                filtered_df["Student Name"].str.lower().str.contains(q, na=False) |
                filtered_df["Additional Feedback"].str.lower().str.contains(q, na=False)
            ]
            
        st.write(f"Showing **{len(filtered_df)}** of **{len(df_records)}** total responses")
        
        # Interactive table
        st.dataframe(
            filtered_df,
            use_container_width=True,
            hide_index=True,
        )
        
        # Export Actions
        e_col1, e_col2 = st.columns([1, 4])
        with e_col1:
            csv_export = filtered_df.to_csv(index=False).encode("utf-8")
            st.download_button(
                label="📥 Export Filtered CSV",
                data=csv_export,
                file_name="filtered_student_survey.csv",
                mime="text/csv",
                use_container_width=True,
            )

# ---------------------------------------------------------
# TAB 4: Workflow & Architecture
# ---------------------------------------------------------
with tab_architecture:
    st.subheader("🏗️ User Input Module Architecture & Workflow")
    
    st.markdown("""
    This project demonstrates an end-to-end data intake and analytical pipeline powered by **Streamlit**, **Python**, **Pandas**, and **CSV Storage**.
    """)
    
    step_col1, step_col2, step_col3, step_col4 = st.columns(4)
    
    with step_col1:
        st.markdown("""
        #### 1️⃣ Step 1: Input
        **Student Enters Details**
        - Name input
        - Department selectbox
        - Academic Year radio
        - Satisfaction rating
        - Additional feedback
        """)
        
    with step_col2:
        st.markdown("""
        #### 2️⃣ Step 2: Submit
        **Form Submission**
        - Atomic form handling
        - Client input validation
        - Timestamp generation
        - Immediate UI response
        """)
        
    with step_col3:
        st.markdown("""
        #### 3️⃣ Step 3: Store
        **CSV File Storage**
        - Appended to `survey_responses.csv`
        - Zero external DB overhead
        - Portable & human-readable
        - Instant file sync
        """)
        
    with step_col4:
        st.markdown("""
        #### 4️⃣ Step 4: Analyse
        **Live Dashboard**
        - Real-time KPIs
        - Altair & Streamlit charts
        - Departmental insights
        - Data export engine
        """)
        
    st.divider()
    
    st.markdown("### 📊 Data Schema Definition")
    schema_df = pd.DataFrame([
        {"Field": "Timestamp", "Type": "DateTime (String)", "Description": "Submission date & time (YYYY-MM-DD HH:MM:SS)"},
        {"Field": "Student Name", "Type": "String", "Description": "Full name or ID of the participating student"},
        {"Field": "Department", "Type": "Categorical", "Description": "Academic department (CSE, ECE, MECH, IT, CIVIL, EEE, AI & DS)"},
        {"Field": "Academic Year", "Type": "Categorical", "Description": "Current academic year (1st Year to 4th Year)"},
        {"Field": "Overall Satisfaction", "Type": "Ordinal", "Description": "Rating scale: Excellent, Good, Average, Poor"},
        {"Field": "Additional Feedback", "Type": "Text", "Description": "Qualitative thoughts, suggestions, or comments"},
    ])
    st.table(schema_df)
