@echo off
echo ========================================================
echo       Launching Student Survey Dashboard...
echo ========================================================
echo.
python -m streamlit run app.py
pause
